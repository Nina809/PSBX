

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;

// Appel de la librarie POI de traitement de fichiers XML, EXCEL, etc
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
 



public class ImportDonnees {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Connexion ala base des donnees 
        String jdbcURL = "jdbc:mysql://localhost:3306/cholera_app";
        String username = "root";
        String password = "";
        
        //Chemin d'acces du fichier Excel Cholera
        String excelFilePath = "C:\\Users\\AllWaysUp\\Documents\\NetBeansProjects\\CholeraApp\\src\\choleraapp\\NINA.xlsx";
        
        //Definition de nombre de ligne A enregistrer dans la base des donnees par tour de boucle (ici c'est le cas de 22 lignes au meme moment
        //pour rendre la requette plus efficiente
        int batchSize = 22;
 
        //Declaration de l'objet de connexion ala base 
        Connection connection = null;
 
        try {
           
            //Transformat du fichier Excel en Objet InputStream 
            FileInputStream inputStream = new FileInputStream(excelFilePath);
            
            //instantiation du classeur Excel avec les classes de la bibliotheques POI
            Workbook workbook = new XSSFWorkbook(inputStream);
            
            //Instantiation de la feuille Excel, Et selection de la premiere feuille du classeur qui nous interesse, qui est ala position 0
            Sheet firstSheet = workbook.getSheetAt(0);
            //Recuperation des lignes de la feuille
            Iterator<Row> rowIterator = firstSheet.iterator();
            
            //Connexion ala Mysql
            connection = DriverManager.getConnection(jdbcURL, username, password);
            connection.setAutoCommit(false);
            
            //Requette PreparEE pour faire transiter les donnees recu from Excel file
            String sql = "INSERT INTO cholera_cmr(ID_Patient,Epiweek, Phone_number, Age_year, Sex, Profession, Village_Quarter,Health_area_of_origin, Health_district_of_origin, Health_area_notifying,Health_district_notifying, Diarrhea_Yes_No, Vomitting_Yes_No, State_of_Dehydratation, Date_of_onset_of_symptoms, Date_of_consultation, Date_of_notification, Hospitalisation_Yes_No, Date_of_hospitalisation, Site_of_case_management, Treatment_ORS_Yes_No, Treatment_Antibiotic_Yes_No,Treatment_IV_liquid_Yes_No, Treatment_Zinc_Yes_No, Date_of_sample_collection, Result_of_RDT,Culture_Yes_No, Result_of_culture, Date_of_discharge, Outcome, Observations, Region)VALUES (?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?)";
            PreparedStatement statement = connection.prepareStatement(sql);    
            
            //compteur de nombre de fois de la boucle recuperer des lignes Excel
            int count = 0;
            
            //Ici on fetch les lignes 
            rowIterator.next(); // Saut de l'entete, pour n.est pas importE les titres des colonnes
            
            //la boucle pour par les lignes Excel
            while (rowIterator.hasNext()) {
                Row nextRow = rowIterator.next();
                Iterator<Cell> cellIterator = nextRow.cellIterator();
                
                //boucle pour parcourir les cellules de la ligne encours,
                //recuperer les donnees de ces cellules, les ajouter al'objet Statement de sql
                while (cellIterator.hasNext()) {
                    Cell nextCell = cellIterator.next();
 
                    int columnIndex = nextCell.getColumnIndex();
 
                    switch (columnIndex) {
                    case 0:
                        String ID_Patient = nextCell.getStringCellValue();
                        statement.setString(1, ID_Patient);
                        break;
                    case 1:
                        int Epiweek = (int) nextCell.getNumericCellValue();                        
                        statement.setInt(2, Epiweek);
                        break;
                    case 2:
                        int Phone_number = (int)nextCell.getNumericCellValue();
                        statement.setInt(3, Phone_number);
                        break;
                    case 3:
                        int Age_year = (int) nextCell.getNumericCellValue();;
                        statement.setInt(4, Age_year);
                        break;    
                    case 4:
                        String Sex = nextCell.getStringCellValue();
                        statement.setString(5, Sex);
                        break;
                    case 5:
                        String Profession = nextCell.getStringCellValue();
                        statement.setString(6, Profession);
                        break;    
                    case 6:
                        String Village_Quarter = nextCell.getStringCellValue();
                        statement.setString(7, Village_Quarter);
                        break;
                    case 7:
                        String Health_area_of_origin = nextCell.getStringCellValue();
                        statement.setString(8, Health_area_of_origin);
                        break;
                        
                    case 8:
                        String Health_district_of_origin = nextCell.getStringCellValue();
                        statement.setString(9, Health_district_of_origin);
                        break;
                    case 9:
                        String Health_area_notifying = nextCell.getStringCellValue();
                        statement.setString(10, Health_area_notifying);
                        break;
                    case 10:
                        String Health_district_notifying = nextCell.getStringCellValue();
                        statement.setString(11, Health_district_notifying);
                        break;
                    case 11:
                        String Diarrhea_Yes_No = nextCell.getStringCellValue();
                        statement.setString(12, Diarrhea_Yes_No);
                        break;
                    case 12:
                        String Vomitting_Yes_No = nextCell.getStringCellValue();
                        statement.setString(13, Vomitting_Yes_No);
                        break;
                    case 13:
                        int State_of_Dehydratation = (int)nextCell.getNumericCellValue();
                        statement.setInt(14,State_of_Dehydratation);
                        break;
                        
                    case 14:
                        Date Date_of_onset_of_symptoms = nextCell.getDateCellValue();
                        statement.setTimestamp(15, new Timestamp(Date_of_onset_of_symptoms.getTime()));
                        break;  
                    
                    case 15:
                        Date Date_of_consultation = nextCell.getDateCellValue();
                        statement.setTimestamp(16, new Timestamp(Date_of_consultation.getTime()));
                        break;
                    case 16:
                        Date Date_of_notification = nextCell.getDateCellValue();
                        statement.setTimestamp(17, new Timestamp(Date_of_notification.getTime()));
                        break;
                    case 17:
                        String Hospitalisation_Yes_No = nextCell.getStringCellValue();
                        statement.setString(18, Hospitalisation_Yes_No);
                        break;
                    case 18:
                        Date Date_of_hospitalisation = nextCell.getDateCellValue();
                        statement.setTimestamp(19, new Timestamp(Date_of_hospitalisation.getTime()) );
                        break;    
                    case 19:
                        String Site_of_case_management = nextCell.getStringCellValue();
                        statement.setString(20, Site_of_case_management);
                        break;
                    case 20:
                        String Treatment_ORS_Yes_No = nextCell.getStringCellValue();
                        statement.setString(21, Treatment_ORS_Yes_No);
                        break;    
                    case 21:
                        String Treatment_Antibiotic_Yes_No = nextCell.getStringCellValue();
                        statement.setString(22, Treatment_Antibiotic_Yes_No);
                        break;
                    case 22:
                        String Treatment_IV_liquid_Yes_No = nextCell.getStringCellValue();
                        statement.setString(23, Treatment_IV_liquid_Yes_No);
                        break;
                        
                    case 23:
                        String Treatment_Zinc_Yes_No = nextCell.getStringCellValue();
                        statement.setString(24, Treatment_Zinc_Yes_No);
                        break;
                    case 24:
                        Date Date_of_sample_collection = nextCell.getDateCellValue();
                        statement.setTimestamp(25, new Timestamp(Date_of_sample_collection.getTime()) );
                        break;
                        
                    case 25:
                        String Result_of_RDT = nextCell.getStringCellValue();
                        statement.setString(26, Result_of_RDT);
                        break;
                    case 26:
                        String Culture_Yes_No = nextCell.getStringCellValue();
                        statement.setString(27, Culture_Yes_No);
                        break;
                    case 27:
                        String Result_of_culture = nextCell.getStringCellValue();
                        statement.setString(28, Result_of_culture);
                        break;
                    case 28:
                        Date Date_of_discharge = nextCell.getDateCellValue();
                        statement.setTimestamp(29, new Timestamp(Date_of_discharge.getTime()));
                        break;
                        
                    case 29:
                        int Outcome = (int)nextCell.getNumericCellValue();
                        statement.setInt(30, Outcome);
                        break;
                    case 30:
                        Double Observations = nextCell.getNumericCellValue();
                        statement.setDouble(31, Observations);
                        break;
                        
                    case 31:
                        String Region = nextCell.getStringCellValue();
                        statement.setString(32, Region);
                        break;
                    }
                    
                }
                //ici on ajoute les lignes a l'objet statement, pour executer en un seul coup , quand que ca sera 22 lignes des donnees
                statement.addBatch();
                 
                //Condition de verification s'il y a deja 22
                if (count % batchSize == 0) {
                    //Execution d'un groupe de 22 requettes ala fois
                    statement.executeBatch();
                }              
 
            }
 
            workbook.close();//fin traitement du fichier
             
            // execution des requetes restantes
            statement.executeBatch();
  
            //finalisation de la requette d'importation
            connection.commit();
            connection.close();
             
          
            System.out.printf("Import des donnEes cholera effectuE \n");
             
        } catch (IOException ex1) {
            System.out.println("Erreur de lecture du fichier");
            ex1.printStackTrace();
        } catch (SQLException ex2) {
            System.out.println("Erreur de la base de donnEes");
            ex2.printStackTrace();
        }
 
    
    }
