/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


/**
 *
 * @author AllWaysUp
 */
public class Ok {
    
    static Connection con =null;
    //Connection conn = null;
   static  ResultSet rs, rs1,rs2, rs3,rs4 = null;
   static  PreparedStatement pst, pst1, pst2,pst3,pst4 = null;
   
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Connexion ala base des donnees de l'hopital
        con =DBConnexion.ConnexionBD();
        
        //Variable de stockage nombre de paatients hospi
        String NbrePatientHommeHospi = "";
        String NbrePatientFemmeHospi = "";
        Double DureeMoyenneHospi = 0.0;
        String Pathologie ="";
        int NbreDiagnotics=0;
        int NbreDiagnoticsParType =0;
        String typeDiagno ="";
        
        //requette NOMBRE DE PATIENTS ADMIS A L'HOSPI PAR GENRE
        String requette = "SELECT COUNT(tab_patient.SEXE) AS PATIENT  FROM `tab_hospitalisation` INNER JOIN tab_patient ON tab_hospitalisation.ID_PATIENT = tab_patient.ID_PATIENT WHERE tab_patient.SEXE = 1";
        String requette1 = "SELECT COUNT(tab_patient.SEXE) AS PATIENT  FROM `tab_hospitalisation` INNER JOIN tab_patient ON tab_hospitalisation.ID_PATIENT = tab_patient.ID_PATIENT WHERE tab_patient.SEXE = 2";
        
        //requette de la duree moyenne de sejour � l'hopital
        String requette2 = "SELECT AVG (DATEDIFF(tab_hospitalisation.DATE_SORTIE,tab_hospitalisation.DATE_ENTREE)) AS DUREEMOYENNESEJOUR FROM tab_hospitalisation";
        
        //Requette des pathologies les plus diagnostiquees
        String requette3 = "SELECT COUNT(tab_diagnostic.ID_DISGNOCTIC) AS NbreDIAGNOSTICS, tab_cim10.LIBELLE_CIM110 AS PATHOLOGIE FROM `tab_diagnostic` INNER JOIN tab_cim10 ON tab_diagnostic.CODE_CIM10 = tab_cim10.ID_CIM10 GROUP BY tab_cim10.LIBELLE_CIM110 HAVING COUNT(tab_diagnostic.ID_DISGNOCTIC) > 39 ORDER BY COUNT(tab_diagnostic.ID_DISGNOCTIC) DESC";
        
        //Requette de repartition des diagnostiques par types
        String requette4 = "SELECT  COUNT(tab_diagnostic.CODE_CIM10) AS DIAGNOSTICS, tab_diagnostic.DGTYPE, CASE  WHEN tab_diagnostic.DGTYPE ='D'  THEN 'Principal' WHEN tab_diagnostic.DGTYPE ='R'  THEN 'Reli�'  WHEN tab_diagnostic.DGTYPE ='S'  THEN 'Associ�'  END AS TYPEDIAGNOTICS FROM `tab_diagnostic` GROUP BY tab_diagnostic.DGTYPE";
        
        try {
            //les donnees d'homme en hospi
            pst = (PreparedStatement) con.prepareStatement(requette);
            rs = pst.executeQuery();
            
            //les donnees des femmmes en hospi
            pst1 = (PreparedStatement) con.prepareStatement(requette1);
            rs1 = pst1.executeQuery();
            
            //les donnees de la duree moyenne d'hospi 
            pst2 = (PreparedStatement) con.prepareStatement(requette2);
            rs2 = pst2.executeQuery();
            
            //les donnees des pathalogies les plus diagnostiques en hospitalisation, DANS NOTRE CAS, PLUS DE 39 FOIS DIAGNOSTIQUEES
            pst3 = (PreparedStatement) con.prepareStatement(requette3);
            rs3 = pst3.executeQuery();
            
            //les donnees des pathalogies les plus diagnostiques en hospitalisation, DANS NOTRE CAS, PLUS DE 39 FOIS DIAGNOSTIQUEES
            pst4 = (PreparedStatement) con.prepareStatement(requette4);
            rs4 = pst4.executeQuery();
            
            System.out.println("1.NOMBRE DE PATIENTS ADMIS A L'HOSPI PAR GENRE ");
            System.out.println("-----------------------------------------------");
            
            while(rs.next()){
                NbrePatientHommeHospi = rs.getString("PATIENT");  
                //Affichage du nombre d'hommes en hospi
                System.out.print("| PATIENTS HOMMES | ");
                System.out.print(NbrePatientHommeHospi);
                System.out.println(" |");
            }
            
            while(rs1.next()){
                 NbrePatientFemmeHospi = rs1.getString("PATIENT"); 
                //Affichage du nombre de femmes en hospi
                System.out.print("| PATIENTS FEMMES | ");
                System.out.print(NbrePatientFemmeHospi);
                System.out.println(" |");
            }
            
            System.out.println("");
            System.out.println("2.LA DUREE MOYENNE DE SEJOUR A L'HOPITAL ");
            System.out.println("-----------------------------------------------");
            
            if(rs2.next()){
                DureeMoyenneHospi = rs2.getDouble("DUREEMOYENNESEJOUR"); 
                //Affichage du nombre de femmes en hospi
                System.out.print("| DUREE MOYENNE | ");
                System.out.print(DureeMoyenneHospi);
                System.out.println(" | JOURS |");
                System.out.println("");
            }
            
             System.out.println("");
            System.out.println("3. LES PATHOLOGIES LES PLUS DIAGNOSTIQUEES CHEZ LES PATIENTS ADMIS A L'HOSPI ");
            System.out.println("------------------------------------------------------------------------------");
            System.out.println("| PATHOLOGIE                             | NBRE DES DIAGNOSTIQUE              |");
            System.out.println("------------------------------------------------------------------------------");
            while(rs3.next()){
                Pathologie = rs3.getString("PATHOLOGIE"); 
                NbreDiagnotics = rs3.getInt("NbreDIAGNOSTICS"); 
                //affichage diagnostics
                
                System.out.println("| "+Pathologie+" | "+NbreDiagnotics);
                 System.out.println("------------------------------------------------------------------------------");
               
            }
            
           
            
            System.out.println("");
            System.out.println("4.REPARTITION DES DIAGNOSTIQUES PAR TYPE ");
            System.out.println("-----------------------------------------------");
            System.out.println("| TYPES |  NBRE DIAGNOSTIQUE ");
            System.out.println("-----------------------------------------------");
            
            while(rs4.next()){
                typeDiagno = rs4.getString("TYPEDIAGNOTICS"); 
                NbreDiagnoticsParType = rs4.getInt("DIAGNOSTICS");
                //Affichage du nombre de femmes en hospi
                System.out.print("| "+typeDiagno+" | "+NbreDiagnoticsParType+" |");
                System.out.println("");
            }
                
                
        } catch (Exception e) {
           // System.out.println(e);
        }
        
       
    }
    
}
