/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author AllWaysUp
 */
public class DBConnexion {
    
    private static String adressURL ="localhost";
    public Connection conn=null;
    private static  String bd_nom = "projet_poo";
    private  static  String utilisateur = "NINAMAX01" ;
    private  static  String mot_de_pass = "Mohamed@89";
    
    
    public static Connection ConnexionBD(){
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mariadb://"+adressURL+":3307/"+bd_nom+"", ""+utilisateur+"", ""+mot_de_pass+"");
            return conn;
        } catch (Exception e) {
           // JOptionPane.showMessageDialog(null, "R�essayez la connexion � la base de donn�es");
            return null;
        }
    }
    
   
    
}

