package Cholera;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



public class CholeraApp {
    
   static Connection con =null;
   static  ResultSet rs, rs1,rs2, rs3,rs4,rs5 = null;
   static  PreparedStatement pst, pst1, pst2,pst3,pst4,pst5 = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("CHOLERA CMR ");
        System.out.println("");
        // Connexion ala base des donnees de l'hopital
        con =DBConnexion.ConnexionBD();
        
         //Variable de stockage nombre de paatients hospi
        String NbrePatientHomme = "";
        String NbrePatientFemme = "";
      
        String nRegion ="";
        int nDeces =0;
        String nDistrict ="";
        int nCas =0;
    
        

        //requette NOMBRE DE  PAR GENRE
        String requette = "SELECT COUNT(cholera_cmr.ID_Patient) AS PATIENT FROM cholera_cmr WHERE Sex = 'F'";
        String requette1 = "SELECT COUNT(cholera_cmr.ID_Patient) AS PATIENT FROM cholera_cmr WHERE Sex = 'M'";
        
        //Requette des cas gueris
        String requette4 = "SELECT COUNT(Outcome) AS Conclusion1, Region FROM `cholera_cmr` WHERE Outcome =2 GROUP BY Region";
        //Requette des cas decedEs
        String requette3 = "SELECT COUNT(Outcome) AS Conclusion, Region FROM `cholera_cmr` WHERE Outcome =3 GROUP BY Region";
        
        //Requette des cas par district
        String requette5 = "SELECT COUNT(ID_Patient) AS nbreCas, Health_district_of_origin FROM `cholera_cmr`  GROUP BY Health_district_of_origin";
        
        
        try {
             //les donnees d'hommes
            pst = (PreparedStatement)con.prepareStatement(requette);
            rs = pst.executeQuery();
            
            //les donnees des femmmes 
            pst1 = (PreparedStatement) con.prepareStatement(requette1);
            rs1 = pst1.executeQuery();
            
            //les donnees du Outcome des cas
            pst3 = (PreparedStatement) con.prepareStatement(requette3);
            rs3 = pst3.executeQuery();
            
            pst4 = (PreparedStatement) con.prepareStatement(requette4);
            rs4 = pst4.executeQuery();
            
            //Les donnees par disticts
            pst5 = (PreparedStatement) con.prepareStatement(requette5);
            rs5 = pst5.executeQuery();
            
            
            
            System.out.println("1.DISTRIBUTION DE CAS PAR GENRE ");
            System.out.println("----------------------------------");
            
            while(rs.next()){
                NbrePatientHomme = rs.getString("PATIENT");  
                //Affichage du nombre d'hommes 
                System.out.print("| PATIENTS HOMMES | ");
                System.out.print(NbrePatientHomme);
                System.out.println(" |");
            }
            
            while(rs1.next()){
                 NbrePatientFemme = rs1.getString("PATIENT"); 
                //Affichage du nombre de femmes 
                System.out.print("| PATIENTS FEMMES | ");
                System.out.print(NbrePatientFemme);
                System.out.println(" |");
            }
            System.out.println("");
            
            System.out.println("");
            System.out.println("2. NOMBRE DE GUERIS PAR REGION ");
            System.out.println("---------------------------------------------------");
            System.out.println("| REGION            | NBRE DES GUERIS             |");
            System.out.println("---------------------------------------------------");
            while(rs4.next()){
                nRegion = rs4.getString("Region"); 
                nDeces = rs4.getInt("Conclusion1"); 
               // affichage les cas gueris par region
                
                System.out.println("| "+nRegion+"                | "+nDeces);
                System.out.println("---------------------------------------------------");
                
               
            }
            System.out.println("");
            
            System.out.println("");
            System.out.println("3. NOMBRE DE DECES PAR REGION ");
            System.out.println("---------------------------------------------------");
            System.out.println("| REGION            | NBRE DES DECES           |");
            System.out.println("---------------------------------------------------");
            while(rs3.next()){
                nRegion = rs3.getString("Region"); 
                nDeces = rs3.getInt("Conclusion"); 
               // affichage les cas deces par region
                
                System.out.println("| "+nRegion+"                | "+nDeces);
                System.out.println("---------------------------------------------------");
                
               
            }
            System.out.println("");
            
            System.out.println("");
            System.out.println("4. DISTRIBUTION DE CAS PAR DISTRICTS ");
            System.out.println("---------------------------------------------------");
            System.out.println("| DISTRICT          | NBRE DES CAS          |");
            System.out.println("---------------------------------------------------");
            while(rs5.next()){
                nDistrict = rs5.getString("Health_district_of_origin"); 
                nCas = rs5.getInt("nbreCas"); 
               // affichage la distribution des cas par district
                
                System.out.println("| "+nDistrict +"      | "+nCas);
                System.out.println("---------------------------------------------------");
                
               
            }
            System.out.println("");
        } catch (Exception e) {
            e.printStackTrace();
        }
       
        
    }
    
}

