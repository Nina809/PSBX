/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cholera;

import java.sql.Connection;
import java.sql.DriverManager;



public class DBConnexion {
    
    private static String adressURL ="localhost";
    public Connection conn=null;
    private static  String bd_nom = "cholera_app";
    private  static  String utilisateur = "root" ;
    private  static  String mot_de_pass = "";
    
    
    public static Connection ConnexionBD(){
        try {
           // Connexion au serveur mysql, ala base de donnees cholera_app
            Connection conn = DriverManager.getConnection("jdbc:mysql://"+adressURL+":3306/"+bd_nom+"", ""+utilisateur+"", ""+mot_de_pass+"");
            return conn;
        } catch (Exception e) {
        	e.printStackTrace();           
            return null;
        }
    }
    
   
}
